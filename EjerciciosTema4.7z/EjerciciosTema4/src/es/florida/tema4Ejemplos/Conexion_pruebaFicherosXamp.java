package es.florida.tema4Ejemplos;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;

public class Conexion_pruebaFicherosXamp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String destino = "www.google.com";
		int puertoDestino = 80;
		Socket socket = new Socket();
		InetSocketAddress direccion = new InetSocketAddress(destino,puertoDestino);
		try {
			socket.connect(direccion);
			InputStream is = socket.getInputStream();
			OutputStream os = socket.getOutputStream();
			System.out.println("Conexi�n realizada");
		} catch (IOException e) {
			System.out.println("Error en la conexi�n");
			e.printStackTrace();
		}
	}

}

package es.florida.tema4;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class AP5_Servidor {
	public static void main(String[] arg) throws IOException, ClassNotFoundException {
		int numeroPuerto = 1234;
		ServerSocket servidor = new ServerSocket(numeroPuerto);
		System.err.println("SERVIDOR >> Escuchando...");
		Socket cliente = servidor.accept();
		ObjectOutputStream outObjeto = new ObjectOutputStream(cliente.getOutputStream());
		Libro book = new Libro("Gepeto el capuchon","Ronald Reagan");
		outObjeto.writeObject(book);
		outObjeto.close();
		cliente.close ();
		servidor.close();
		}
}

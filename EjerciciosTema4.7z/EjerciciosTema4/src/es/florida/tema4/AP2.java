package es.florida.tema4;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import javax.imageio.ImageIO;

public class AP2 {
	
	public static void descargarImagen(String url_descargar, String nombreArchivo) {
		
		System.out.println(" Descargando " + url_descargar);
		
	    try {
	    	URL url = new URL(url_descargar);
	    	InputStream in = new BufferedInputStream(url.openStream());
	    	ByteArrayOutputStream out = new ByteArrayOutputStream();
	    	byte[] buf = new byte[1024];
	    	int n = 0;
	    	while (-1!=(n=in.read(buf)))
	    	{
	    	   out.write(buf, 0, n);
	    	}
	    	out.close();
	    	in.close();
	    	byte[] response = out.toByteArray();
	    	FileOutputStream fos = new FileOutputStream(nombreArchivo);
	    	fos.write(response);
	    	fos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	}
	
	public static void main(String[] args) {
		String url =
				"http://localhost:80"+
				"/dam2/amongus.png";
		String fichero = "amongus.png";
		descargarImagen(url,fichero);

	}

}

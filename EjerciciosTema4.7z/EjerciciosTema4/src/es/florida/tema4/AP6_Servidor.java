package es.florida.tema4;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class AP6_Servidor {
	public static void main(String[] arg) throws IOException, ClassNotFoundException {
		int numeroPuerto = 1234;
		ServerSocket servidor = new ServerSocket(numeroPuerto);
		System.err.println("SERVIDOR >> Escuchando...");
		Socket cliente = servidor.accept();
		ObjectOutputStream outObjeto = new ObjectOutputStream(cliente.getOutputStream());
		Libro book = new Libro("Drakukeo el empalador","Padua Keoma Salas S�nchez");
		outObjeto.writeObject(book);
		System.err.println("SERVIDOR >> Envio a cliente: " + book.getTitulo() + " - " + book.getAutor());
		ObjectInputStream inObjeto = new ObjectInputStream(cliente.getInputStream());
		Libro bMod = (Libro) inObjeto.readObject();
		System.err.println("SERVIDOR >> Recibo de cliente: " + bMod.getTitulo()+ " - " + bMod.getAutor()); 
		outObjeto.close();
		cliente.close ();
		servidor.close();
		}
}

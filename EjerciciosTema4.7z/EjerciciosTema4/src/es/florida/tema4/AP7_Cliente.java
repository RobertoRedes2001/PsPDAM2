package es.florida.tema4;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class AP7_Cliente {
	public static void main(String[] arg) throws UnknownHostException, IOException,
	ClassNotFoundException {
	String host = "localhost";
	int puerto = 1234;
	System.out.println("CLIENTE >> Arranca cliente");
	Socket cliente = new Socket(host,puerto);
	ObjectInputStream inObjeto = new ObjectInputStream(cliente.getInputStream());
	Libro book = (Libro) inObjeto.readObject();
	System.out.println("CLIENTE >> Recibo del servidor: "+book.getTitulo() + " - " + book.getAutor());
	book.setTitulo("Drakukeo, el emperador");
	ObjectOutputStream pMod = new ObjectOutputStream(cliente.getOutputStream());
	pMod.writeObject(book);
	System.out.println("CLIENTE >> Envio al servidor: "+book.getTitulo() + " - " + book.getAutor());
	inObjeto.close();
	pMod.close();
	cliente.close();
	}
}

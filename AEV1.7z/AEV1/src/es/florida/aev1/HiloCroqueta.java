package es.florida.aev1;

import java.util.List;

public class HiloCroqueta implements Runnable {
	
	private String tipoCroqueta;
	private long tiempoFabricacion;
	
	public HiloCroqueta(String tipoCroqueta, long tiempoFabricacion) {
		this.tipoCroqueta = tipoCroqueta;
		this.tiempoFabricacion = tiempoFabricacion;

	}

	@Override
	public void run() {
		
		synchronized (this) {
			try {
				System.out.println("Fabricando croqueta de "+tipoCroqueta+"...");
				Thread.sleep(tiempoFabricacion);
				Procesadora.maximoProcesable++;
				System.out.println("Croqueta fabricada "+tipoCroqueta+"!!!");
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
		}	
			
	}
	
}

package es.florida.aev1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.Color;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Lanzadora extends JFrame {
	
	
	public static void ejecutar(int crocoHam, int crocoChese, int crocoChicken, int crocoFish, String priority){
		
		String clase = "es.florida.aev1.Procesadora";
		String javaHome = System.getProperty("java.home");
		String javaBin = javaHome + File.separator + "bin" + File.separator + "java";
		String classpath = System.getProperty("java.class.path");
		String className = clase;
		
		List<String> command = new ArrayList<String>();
		
		command.add(javaBin);
		command.add("-cp");
		command.add(classpath);
		command.add(className);
		command.add(String.valueOf(crocoHam));
		command.add(String.valueOf(crocoChese));
		command.add(String.valueOf(crocoChicken));
		command.add(String.valueOf(crocoFish));
		command.add(priority);
		ProcessBuilder builder = new ProcessBuilder(command);
		
		try {
			Process p = builder.inheritIO().start();
			p.waitFor();
			JOptionPane.showMessageDialog(null, "Croquetas Cocinadas!!!");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private JPanel contentPane;
	private JLabel lblTitulo;
	private JLabel lblJamon;
	private JLabel lblQueso;
	private JLabel lblPollo;
	private JLabel lblBacalao;
	private JSpinner spnJamon;
	private JSpinner spnQueso;
	private JSpinner spnPollo;
	private JSpinner spnBacalao;
	private JButton btnFabricar;
	private JComboBox cmbPrioridad;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Lanzadora frame = new Lanzadora();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Lanzadora() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1001, 369);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblTitulo = new JLabel("SUPER CROQUETO");
		lblTitulo.setFont(new Font("Tahoma", Font.PLAIN, 50));
		lblTitulo.setBounds(270, 43, 473, 90);
		contentPane.add(lblTitulo);
		
		lblJamon = new JLabel("Jamon: ");
		lblJamon.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblJamon.setBounds(162, 165, 70, 30);
		contentPane.add(lblJamon);
		
		lblQueso = new JLabel("Queso:");
		lblQueso.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblQueso.setBounds(322, 165, 70, 30);
		contentPane.add(lblQueso);
		
		lblPollo = new JLabel("Pollo: ");
		lblPollo.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblPollo.setBounds(482, 165, 70, 30);
		contentPane.add(lblPollo);
		
		lblBacalao = new JLabel("Bacalao:");
		lblBacalao.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblBacalao.setBounds(642, 165, 70, 30);
		contentPane.add(lblBacalao);
		
		spnJamon = new JSpinner();
		spnJamon.setModel(new SpinnerNumberModel(Integer.valueOf(0), Integer.valueOf(0), null, Integer.valueOf(1)));
		spnJamon.setFont(new Font("Tahoma", Font.PLAIN, 16));
		spnJamon.setBounds(253, 165, 48, 30);
		contentPane.add(spnJamon);
		
		spnQueso = new JSpinner();
		spnQueso.setModel(new SpinnerNumberModel(Integer.valueOf(0), Integer.valueOf(0), null, Integer.valueOf(1)));
		spnQueso.setFont(new Font("Tahoma", Font.PLAIN, 16));
		spnQueso.setBounds(413, 165, 48, 30);
		contentPane.add(spnQueso);
		
		spnBacalao = new JSpinner();
		spnBacalao.setModel(new SpinnerNumberModel(Integer.valueOf(0), Integer.valueOf(0), null, Integer.valueOf(1)));
		spnBacalao.setFont(new Font("Tahoma", Font.PLAIN, 16));
		spnBacalao.setBounds(733, 165, 48, 30);
		contentPane.add(spnBacalao);
		
		spnPollo = new JSpinner();
		spnPollo.setModel(new SpinnerNumberModel(Integer.valueOf(0), Integer.valueOf(0), null, Integer.valueOf(1)));
		spnPollo.setFont(new Font("Tahoma", Font.PLAIN, 16));
		spnPollo.setBounds(573, 165, 48, 30);
		contentPane.add(spnPollo);
		
		JLabel lblPrioridad = new JLabel("Prioridad:");
		lblPrioridad.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblPrioridad.setBounds(162, 248, 70, 30);
		contentPane.add(lblPrioridad);
		
		btnFabricar = new JButton("HACER PEDIDO");
		btnFabricar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ejecutar((Integer) spnJamon.getValue(),(Integer) spnQueso.getValue(),
						(Integer) spnPollo.getValue(),(Integer) spnBacalao.getValue(),
						cmbPrioridad.getSelectedItem().toString());
				
			}
		});
		btnFabricar.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnFabricar.setBounds(573, 248, 208, 30);
		contentPane.add(btnFabricar);
		
		cmbPrioridad = new JComboBox();
		cmbPrioridad.setFont(new Font("Tahoma", Font.PLAIN, 16));
		cmbPrioridad.setModel(new DefaultComboBoxModel(new String[] {"Jamon", "Queso", "Pollo", "Bacalao"}));
		cmbPrioridad.setBounds(253, 248, 108, 30);
		contentPane.add(cmbPrioridad);
	}
	
}

package es.florida.aev1;

public class Procesadora {
	
	private int cantJamon;
	private int cantQueso;
	private int cantPollo;
	private int cantBacalao;
	private String prioridad;
	
	public Procesadora(int cantJamon, int cantQueso, int cantPollo, int cantBacalao, String prioridad) {
		this.cantJamon = cantJamon;
		this.cantQueso = cantQueso;
		this.cantPollo = cantPollo;
		this.cantBacalao = cantBacalao;
		this.prioridad = prioridad;
	}

	public void procesamiento(String tipo, long tiempo, int cantidad) {
		for (int i = 0 ; i < cantidad;i++){
			HiloCroqueta croqueta = new HiloCroqueta(tipo,tiempo);
			Thread hilo = new Thread(croqueta);
			hilo.start();
		}
		
	}
	
	public void procesarCroquetos() {
		
		switch(prioridad) {
		case "Jamon":
			procesamiento("Jamon",5000,this.cantJamon);
			procesamiento("Queso",8000,this.cantQueso);
			procesamiento("Pollo",6000,this.cantPollo);
			procesamiento("Bacalao",7000,this.cantBacalao);
			break;
		case "Queso":
			procesamiento("Queso",8000,this.cantQueso);
			procesamiento("Jamon",5000,this.cantJamon);
			procesamiento("Pollo",6000,this.cantPollo);
			procesamiento("Bacalao",7000,this.cantBacalao);
			break;
		case "Pollo":
			procesamiento("Pollo",6000,this.cantPollo);
			procesamiento("Queso",8000,this.cantQueso);
			procesamiento("Jamon",5000,this.cantJamon);
			procesamiento("Bacalao",7000,this.cantBacalao);
			break;
		case "Bacalao":
			procesamiento("Bacalao",7000,this.cantBacalao);
			procesamiento("Jamon",5000,this.cantJamon);
			procesamiento("Queso",8000,this.cantQueso);
			procesamiento("Pollo",6000,this.cantPollo);
			break;
		}
		
	}


	public static void main(String[] args) {
	
		Procesadora proceso = new Procesadora(Integer.parseInt(args[0]),Integer.parseInt(args[1]),
				Integer.parseInt(args[2]),Integer.parseInt(args[3]),args[4]);
		
		proceso.procesarCroquetos();
		
	}

}

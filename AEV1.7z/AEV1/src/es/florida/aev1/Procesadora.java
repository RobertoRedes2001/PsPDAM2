package es.florida.aev1;

import java.text.DecimalFormat;

public class Procesadora {
	
	private int cantJamon;
	private int cantQueso;
	private int cantPollo;
	private int cantBacalao;
	private String prioridad;
	static int maximoProcesable = 100;
	
	
	public Procesadora() {
		
	}
	public Procesadora(int cantJamon, int cantQueso, int cantPollo, int cantBacalao, String prioridad) {
		this.cantJamon = cantJamon;
		this.cantQueso = cantQueso;
		this.cantPollo = cantPollo;
		this.cantBacalao = cantBacalao;
		this.prioridad = prioridad;
	}

	public void procesamiento(String tipo, long tiempo, int cantidad) {
		
		for (int i = 0; i < cantidad; i++) {
			while(maximoProcesable==0) {
				System.out.println("Estamos trabajando en su pedido. Por favor, espere...");
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			HiloCroqueta croqueta = new HiloCroqueta(tipo, tiempo);
			Thread hilo = new Thread(croqueta);
			System.out.println("Croquetas procesadas: "+(1+i));
			hilo.start();
			maximoProcesable--;
		}
		
	}
	
	public void procesarCroquetos() {
		
		switch(prioridad) {
		case "Jamon":
			procesamiento("Jamon",5000,this.cantJamon);
			procesamiento("Queso",8000,this.cantQueso);
			procesamiento("Pollo",6000,this.cantPollo);
			procesamiento("Bacalao",7000,this.cantBacalao);
		    
		   
			break;
		case "Queso":
			procesamiento("Queso",8000,this.cantQueso);
			procesamiento("Jamon",5000,this.cantJamon);
			procesamiento("Pollo",6000,this.cantPollo);
			procesamiento("Bacalao",7000,this.cantBacalao);
			break;
		case "Pollo":
			procesamiento("Pollo",6000,this.cantPollo);
			procesamiento("Queso",8000,this.cantQueso);
			procesamiento("Jamon",5000,this.cantJamon);
			procesamiento("Bacalao",7000,this.cantBacalao);
			break;
		case "Bacalao":
			procesamiento("Bacalao",7000,this.cantBacalao);
			procesamiento("Jamon",5000,this.cantJamon);
			procesamiento("Queso",8000,this.cantQueso);
			procesamiento("Pollo",6000,this.cantPollo);
			break;
		}
		
	}


	public static void main(String[] args) {
	
		Procesadora proceso = new Procesadora(Integer.parseInt(args[0]),Integer.parseInt(args[1]),
				Integer.parseInt(args[2]),Integer.parseInt(args[3]),args[4]);
		
		proceso.procesarCroquetos();
		
	}

}
